	$(document).ready(function () {
		$("#image404").toggleClass('flip');
		$("#error-heading").toggleClass('flip-again');
		$("#page_not_found_image").toggleClass('flap');
		$("#csrf_error").toggleClass('flap-again');
		$("#error_500").toggleClass('flop');
	});